import path from 'path';
import HtmlWebpackPlugin from 'html-webpack-plugin';
import CopyWebpackPlugin from 'copy-webpack-plugin';
import { CleanWebpackPlugin } from 'clean-webpack-plugin';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import WorkboxWebpackPlugin from 'workbox-webpack-plugin';

const currentDir = dirname(fileURLToPath(import.meta.url));

export default {
  entry: {
    app: path.resolve(currentDir, 'src/index.js'),
    // sw: path.resolve(currentDir, 'src/sw.js'),
  },
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(currentDir, 'dist'),
    clean: true,
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          {
            loader: 'style-loader',
          },
          {
            loader: 'css-loader',
          },
        ],
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(),
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: path.resolve(currentDir, 'src/templates/index.html'),
    }),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: path.resolve(currentDir, 'src/public/'),
          to: path.resolve(currentDir, 'dist/'),
        },
      ],
    }),

    new WorkboxWebpackPlugin.GenerateSW({
      swDest: './sw.bundle.js',
      runtimeCaching: [
        {
          urlPattern: ({ url }) => url.href.startsWith('https://restaurant-api.dicoding.dev'), 
          handler: 'StaleWhileRevalidate',
          options: {
            cacheName: 'restaurant-api-cache',
          },
        },
        {
          urlPattern: ({ url }) => url.href.startsWith('https://restaurant-api.dicoding.dev/images/small/<pictureId>'), 
          handler: 'StaleWhileRevalidate',
          options: {
            cacheName: 'restaurant-images-small-cache',
          },
        },
        {
          urlPattern: ({ url }) => url.href.startsWith('https://restaurant-api.dicoding.dev/images/medium/<pictureId>'), 
          handler: 'StaleWhileRevalidate',
          options: {
            cacheName: 'restaurant-images-medium-cache',
          },
        },
        {
          urlPattern: ({ url }) => url.href.startsWith('https://restaurant-api.dicoding.dev/images/large/<pictureId>'), 
          handler: 'StaleWhileRevalidate',
          options: {
            cacheName: 'restaurant-images-large-cache',
          },
        },
      ],
    }),
  ],
};
