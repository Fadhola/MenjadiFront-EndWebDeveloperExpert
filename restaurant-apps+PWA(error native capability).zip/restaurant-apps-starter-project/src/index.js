/* eslint-disable no-console */
import 'regenerator-runtime';
import './styles/main.css';
import App from './views/app';
import swRegister from './sw-register';

const setupMenu = () => {
  const menuIcon = document.getElementById('menu-icon');
  const navMenu = document.getElementById('nav-menu');
  const navDrawer = document.getElementById('nav-drawer');

  menuIcon.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    navDrawer.classList.toggle('active');

    if (navMenu.classList.contains('active')) {
      navMenu.querySelector('a').focus();
    } else {
      menuIcon.focus();
    }
  });
};

const app = new App({
  button: document.querySelector('#menu-icon'),
  drawer: document.querySelector('#nav-drawer'),
  content: document.querySelector('#main-content'),
});

const renderApp = async () => {
  setupMenu(); 
  await app.renderPage();
};

window.addEventListener('hashchange', renderApp);
window.addEventListener('load', () => {
  renderApp();
  swRegister();
});
