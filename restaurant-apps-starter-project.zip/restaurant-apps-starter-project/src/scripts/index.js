import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import './script.js';

console.log('Hello Coders! :)');


