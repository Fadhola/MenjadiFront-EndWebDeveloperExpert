/* eslint-disable linebreak-style */
/* eslint-disable no-shadow */
/* eslint-disable max-len */
/* eslint-disable no-undef */
/* eslint-disable linebreak-style */
Feature('Integration Test');

Scenario('User can like and unlike a restaurant', async ({ I }) => {
  I.amOnPage('/#/restaurant/rqdv5juczeskfw1e867');
  I.waitForElement('#add-to-favorite-button');

  I.click('#add-to-favorite-button');
  I.acceptPopup();

  I.waitForText('Restaurant added to favorites.', 5, '#add-to-favorite-button');

  I.click('#add-to-favorite-button');
  I.acceptPopup();

  I.waitForText('Restaurant removed from favorites.', 5, '#add-to-favorite-button');
});
