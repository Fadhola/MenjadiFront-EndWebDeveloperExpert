/* eslint-disable linebreak-style */
/* eslint-disable no-undef */
/* eslint-disable linebreak-style */
Feature('End-to-End Test');

Scenario('User can like and unlike a restaurant', async ({ I }) => {
  I.amOnPage('/');
  I.waitForElement('.restaurant-card');

  I.click('.restaurant-detail-button');
  I.waitForElement('#add-to-favorite-button');

  I.click('#add-to-favorite-button');
  I.acceptPopup();

  I.wait(2);
  I.see('Restaurant added to favorites.', '#add-to-favorite-button');

  I.click('Back');
  I.waitForElement('.restaurant-card');

  I.click('.restaurant-detail-button');
  I.waitForElement('#add-to-favorite-button');

  I.click('#add-to-favorite-button');
  I.acceptPopup();

  I.wait(2);
  I.see('Restaurant removed from favorites.', '#add-to-favorite-button');
});
