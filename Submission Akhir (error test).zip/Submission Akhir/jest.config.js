module.exports = {
  // Mengonfigurasi file yang akan diuji
  testMatch: ['**/tests/**/*.test.js'],

  // Mengonfigurasi environment pengujian
  testEnvironment: 'node', // Jika Anda tidak menggunakan browser

  // Opsional: mengonfigurasi setupFiles atau setupFilesAfterEnv untuk setup tambahan
  // setupFiles: ['<path-to-setup-file>'],

  transform: {
    '^.+\\.js$': 'babel-jest',
  },

  // Opsional: mengonfigurasi modul mocks atau modul yang di-ignore
  // moduleNameMapper: {
  //   '^module-name$': '<path-to-mock>',
  // },

  // Opsional: mengonfigurasi coverage report
  // coverageReporters: ['json', 'lcov', 'text', 'clover'],

  // Opsional: mengonfigurasi path untuk coverage report output
  // coverageDirectory: 'coverage',

  // Opsional: konfigurasi tambahan
  // ...
};
