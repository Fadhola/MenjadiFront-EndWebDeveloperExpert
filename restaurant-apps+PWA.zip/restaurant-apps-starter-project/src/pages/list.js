import { getAllRestaurants } from '../globals/api-endpoint';

export const renderRestaurantList = async () => {
  try {
    const restaurants = await getAllRestaurants();
    const restaurantListContainer = document.getElementById('main-content');

    restaurantListContainer.innerHTML = ''; 

    restaurants.forEach((restaurant) => {
      const restaurantItem = createRestaurantItem(restaurant);
      restaurantListContainer.appendChild(restaurantItem);
    });
  } catch (error) {
    console.error('Error rendering restaurant list:', error);
  }
};

const createRestaurantItem = (restaurant) => {
  const restaurantItem = document.createElement('div');
  restaurantItem.innerHTML = `
    <h2>${restaurant.name}</h2>
    <img src="${restaurant.pictureId}" alt="${restaurant.name}">
    <p>${restaurant.city}</p>
    <p>Rating: ${restaurant.rating}</p>
    <p>${restaurant.description}</p>
    <a href="#/restaurant/${restaurant.id}">Lihat Detail</a>
  `;
  return restaurantItem;
};
