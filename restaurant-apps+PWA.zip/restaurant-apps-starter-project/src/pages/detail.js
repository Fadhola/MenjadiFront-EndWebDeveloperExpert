import { getRestaurantDetail, addFavoriteRestaurant, removeFavoriteRestaurant } from '../globals/api-endpoint';

const renderRestaurantDetail = async () => {
  const url = new URL(window.location.href);
  const restaurantId = url.hash.substring(14); 
  const restaurantDetailContainer = document.getElementById('restaurant-detail');
  
  try {
    const restaurantDetail = await getRestaurantDetail(restaurantId);
    
    restaurantDetailContainer.innerHTML = `
      <h2>${restaurantDetail.name}</h2>
      <img src="${restaurantDetail.pictureId}" alt="${restaurantDetail.name}">
      <p><strong>Alamat:</strong> ${restaurantDetail.address}</p>
      <p><strong>Kota:</strong> ${restaurantDetail.city}</p>
      <p><strong>Deskripsi:</strong> ${restaurantDetail.description}</p>
      <h3>Menu Makanan:</h3>
      <ul>
        ${restaurantDetail.menus.foods.map((food) => `<li>${food.name}</li>`).join('')}
      </ul>
      <h3>Menu Minuman:</h3>
      <ul>
        ${restaurantDetail.menus.drinks.map((drink) => `<li>${drink.name}</li>`).join('')}
      </ul>
      <h3>Customer Reviews:</h3>
      <ul>
        ${restaurantDetail.customerReviews.map((review) => `<li><strong>${review.name}</strong> - ${review.date}: ${review.review}</li>`).join('')}
      </ul>
    `;
    
    const favoriteButton = document.createElement('button');
    favoriteButton.textContent = 'Favorite';
    favoriteButton.id = 'favorite-button';
    restaurantDetailContainer.appendChild(favoriteButton);
    

    let isFavorite = await checkFavorite(restaurantId); 
    if (isFavorite) {
      favoriteButton.textContent = 'Unfavorite';
    }
    
    favoriteButton.addEventListener('click', async () => {
      if (isFavorite) {
        await removeFavoriteRestaurant(restaurantId);
        favoriteButton.textContent = 'Favorite';
      } else {
        await addFavoriteRestaurant(restaurantId);
        favoriteButton.textContent = 'Unfavorite';
      }
      isFavorite = !isFavorite;
    });
  } catch (error) {
    console.error('Error rendering restaurant detail:', error);
  }
};

const checkFavorite = async (restaurantId) => {
  const response = await getAllFavoriteRestaurants();
  const favoriteRestaurants = response.restaurants;
  return favoriteRestaurants.some((restaurant) => restaurant.id === restaurantId);
};

export { renderRestaurantDetail }; 
