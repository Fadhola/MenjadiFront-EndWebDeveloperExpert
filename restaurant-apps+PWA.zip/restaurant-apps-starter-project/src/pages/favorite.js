import { openDB } from 'idb';
import { removeFavoriteRestaurant, getAllFavoriteRestaurants } from '../globals/api-endpoint';

const dbPromise = openDB('restaurant-db', 1, {
  upgrade(db) {
    const store = db.createObjectStore('restaurants', {
      keyPath: 'id',
    });
    store.createIndex('name', 'name');
  },
});

export const renderFavoriteRestaurants = async () => {
  const restaurantListContainer = document.getElementById('main-content');

  try {
    const db = await dbPromise;
    const tx = db.transaction('restaurants', 'readonly');
    const store = tx.objectStore('restaurants');
    const restaurants = await store.getAll();
    tx.done;

    if (restaurants.length === 0) {
      restaurantListContainer.innerHTML = '<p>Tidak ada restoran favorit.</p>';
    } else {
      restaurantListContainer.innerHTML = '';

      restaurants.forEach((restaurant) => {
    
        const favoriteRestaurantItem = document.createElement('div');
        favoriteRestaurantItem.innerHTML = `
          <h2>${restaurant.name}</h2>
          <img src="${restaurant.pictureId}" alt="${restaurant.name}">
          <p>${restaurant.city}</p>
          <p>Rating: ${restaurant.rating}</p>
          <p>${restaurant.description}</p>
          <a href="#/restaurant/${restaurant.id}">Lihat Detail</a>
          <button data-restaurant-id="${restaurant.id}" class="unfavorite-button">Unfavorite</button>
        `;
        restaurantListContainer.appendChild(favoriteRestaurantItem);
      });

      const unfavoriteButtons = document.querySelectorAll('.unfavorite-button');
      unfavoriteButtons.forEach((button) => {
        button.addEventListener('click', async (event) => {
          const restaurantId = event.target.getAttribute('data-restaurant-id');
          await removeFavoriteRestaurant(restaurantId);

          event.target.parentElement.remove();
        });
      });
    }
  } catch (error) {
    console.error('Error rendering favorite restaurant list:', error);
  }
};
