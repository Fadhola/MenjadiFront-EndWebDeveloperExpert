self.addEventListener('install', (event) => {
    event.waitUntil(
      caches.open('restaurant-app-v1').then((cache) => {
        return cache.addAll([
          '/',
          '/index.html',
          '/manifest.json',
          '/sw.js',
          '/src/index.js',
          '/src/initiator.js',
          '/src/utils/api.js',
          '/src/utils/db.js',
          '/src/pages/detail.js',
          '/src/pages/like.js',
          '/src/pages/list.js',
          '/src/styles/main.css',
          '/src/templates/template-creator.js',
          'https://fonts.googleapis.com/css?family=Open+Sans:400,700',
        ]);
      })
    );
  });
  
  self.addEventListener('fetch', (event) => {
    event.respondWith(
      caches.match(event.request).then((response) => {
        return response || fetch(event.request);
      })
    );
  });