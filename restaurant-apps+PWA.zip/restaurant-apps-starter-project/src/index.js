import 'regenerator-runtime'; 
import './styles/main.css'; 
import { renderRestaurantList } from './pages/list';
import { renderFavoriteRestaurants } from './pages/favorite';
import { renderRestaurantDetail } from './pages/detail';

const routes = {
  '/': renderRestaurantList,
  '/favorites': renderFavoriteRestaurants,
  '/restaurant': renderRestaurantDetail,
};

const renderPage = async () => {
  const route = window.location.hash.split('?')[0];
  const content = document.getElementById('main-content');
  content.innerHTML = '';
  if (routes[route]) {
    const page = new routes[route](); 
    content.appendChild(await page.render()); 
    console.log(`Rendered page for route: ${route}`); 
  }
};

window.addEventListener('hashchange', renderPage);
window.addEventListener('load', renderPage);
